class TagController < ApplicationController
  def list_tags
	  @title_for_post = "List tags";
  end
end
